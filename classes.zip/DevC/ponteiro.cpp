#include "ponteiro.h"

Ponteiro::Ponteiro(){
	
}

int Ponteiro::ponteiros(int *ptr){
	int pt = *ptr;
	return pt;
}
