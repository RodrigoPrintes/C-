#ifndef CAST_H
#define CAST_H

class Cast {
public:
 
    Cast();
    double int2double(int n1, int n2);

};

#endif
