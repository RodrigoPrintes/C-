#ifndef VETORES_H
#define VETORES_H

class Vetores{
	public:
		Vetores();
		int vetor(int index);
};
#endif
