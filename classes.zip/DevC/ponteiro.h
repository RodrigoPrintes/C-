#ifndef PONTEIRO_H
#define PONTEIRO_H

class Ponteiro {
public:
 
    Ponteiro();
    int ponteiros(int *n1);

};

#endif
